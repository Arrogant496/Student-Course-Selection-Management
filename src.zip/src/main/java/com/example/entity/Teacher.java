package com.example.entity;

/**
 * 教师
*/
public class Teacher extends Account {

    /** ID */
    private Integer id;
    /** 用户名 */
    private String username;
    /** 密码 */
    private String password;
    /** 姓名 */
    private String name;
    /** 性别 */
    private String sex;
    /**  职称 */
    private  String title;
    /**  绑定专业*/
    private Integer specialityId;
    /** 角色标识 */
    private String role;
    /**  头像 */
    private String avatar;

    private  String specialityName;

    @Override
    public String getAvatar() {
        return avatar;
    }

    @Override
    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getName() {
        return name;
    }
    public String getSex() {
        return sex;
    }

    public String getTitle() {
        return title;
    }

    public Integer getSpecialityId() {
        return specialityId;
    }

    @Override
    public String getRole() {
        return role;
    }

    @Override
    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSpecialityId(Integer specialityId) {
        this.specialityId = specialityId;
    }

    @Override
    public void setRole(String role) {
        this.role = role;
    }

    public String getSpecialityName() {
        return specialityName;
    }

    public void setSpecialityName(String specialityName) {
        this.specialityName = specialityName;
    }
}