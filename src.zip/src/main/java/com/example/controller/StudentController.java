package com.example.controller;
import com.example.common.Result;
import com.example.entity.Student;
import com.example.service.StudentService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 学生模块前端请求的接口入口
 */
@RestController
@RequestMapping("/student")
public class StudentController {
    @Resource
    private StudentService studentService;
    //新增
    @PostMapping("/add")
    public Result add(@RequestBody Student student){
        studentService.add(student);
        return Result.success();
    }
    //更新
    @PutMapping("/update")
    public Result update(@RequestBody Student student){
        studentService.updateById(student);
        return Result.success();
    }
    //根据id删除
    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Integer id){
        studentService.deleteById(id);
        return Result.success();
    }

    //根据id查询
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id){
        return Result.success(studentService.selectById(id));
    }

    //分页查询
    @GetMapping("/selectPage")
    public  Result selectPage(Student student,
                              @RequestParam(defaultValue = "1") Integer pageNum,
                              @RequestParam(defaultValue = "5") Integer pageSize){
        PageInfo<Student> pageInfo=studentService.selectPage(student,pageNum,pageSize);
        return  Result.success(pageInfo);
    }
}
