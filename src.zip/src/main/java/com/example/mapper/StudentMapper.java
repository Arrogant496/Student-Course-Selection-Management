package com.example.mapper;
import com.example.entity.Student;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

public interface StudentMapper {
    void insert(Student student);

    List<Student> selectAll();

    List<Student> selectByName(String name);

    Student selectById(Integer id);

    Student selectByUsername(String username);

    void updateById(Student student);
@Delete("delete from student where id = #{id}")
    void deleteById(Integer id);
}