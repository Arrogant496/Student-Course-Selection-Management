package com.example.service;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.ObjectUtil;
import com.example.entity.Choice;
import com.example.entity.Course;
import com.example.exception.CustomException;
import com.example.mapper.ChoiceMapper;
import com.example.mapper.CourseMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 选课信息业务层处理
 */
@Service
public class ChoiceService {
    @Resource
    private ChoiceMapper choiceMapper;
    @Resource
    private CourseMapper courseMapper;

    /**
     * 检查课程时间冲突
     * @param studentId 学生ID
     * @param newCourseTime 新选课程的时间
     */
    private void checkTimeConflict(Integer studentId, String newCourseTime) {
        // 获取学生已选的所有课程
        List<Choice> choices = choiceMapper.selectAllByStudentId(studentId);
        
        if (CollectionUtil.isEmpty(choices)) {
            // 如果学生没有选任何课程，直接返回，没有冲突
            return;
        }
        
        // 遍历学生已选的课程，检查时间冲突
        for (Choice choice : choices) {
            // 获取已选课程的详细信息，包括上课时间
            Course selectedCourse = courseMapper.selectById(choice.getCourseId());
            if (selectedCourse != null && selectedCourse.getTime() != null && newCourseTime != null) {
                // 检查时间是否冲突（这里假设time字段包含了完整的上课时间信息）
                if (selectedCourse.getTime().equals(newCourseTime)) {
                    throw new CustomException("课程时间冲突：您已选择时间相同的课程 " + selectedCourse.getName() + "，无法重复选择");
                }
            }
        }
    }

    public void add(Course course) {
        //1.先判断课程有没有满员
        if (course.getNum().equals(course.getAlreadyNum())) {
            throw new CustomException("该门课已经满员，请选择其它课程");
        }
        //2.判断学生有没有选过该门课
        List<Choice> list = choiceMapper.selectByCourseIdAndStudentId(course.getId(), course.getStudentId());
        if (CollectionUtil.isNotEmpty(list)) {
            throw new CustomException("您已经选过该门课程");
        }
        //3.检查时间冲突
        checkTimeConflict(course.getStudentId(), course.getTime());
        //4.往选课信息表里插入一条选课记录
        Choice choice = new Choice();
        choice.setName(course.getName());
        choice.setTeacherId(course.getTeacherId());
        choice.setStudentId(course.getStudentId());
        choice.setCourseId(course.getId());
        choiceMapper.insert(choice);
        //5.该门课的已选人数＋1
        course.setAlreadyNum(course.getAlreadyNum() + 1);
        courseMapper.updateById(course);
    }

    public PageInfo<Choice> selectPage(Choice choice, Integer pageNum, Integer pageSize) {
        List<Choice> list;
        PageHelper.startPage(pageNum, pageSize);
        if (ObjectUtil.isNotEmpty(choice.getStudentId())) {
            //说明这是学生登入进行分页查询
            if (ObjectUtil.isNotEmpty(choice.getName())) {
                list = choiceMapper.selectByNameAndStudentId(choice.getName(), choice.getStudentId());
            } else {
                list = choiceMapper.selectAllByStudentId(choice.getStudentId());
            }
        } else if (ObjectUtil.isNotEmpty(choice.getTeacherId())) {
            //说明这是教师登录进行分页查询
            if (ObjectUtil.isNotEmpty(choice.getName())) {
                list = choiceMapper.selectByNameAndTeacherId(choice.getName(), choice.getTeacherId());
            } else {
                list = choiceMapper.selectAllByTeacherId(choice.getTeacherId());
            }
        } else {

            //说明这是管理员进行分页查询
         if (ObjectUtil.isNotEmpty(choice.getName())) {
            list = choiceMapper.selectByName(choice.getName());
        } else {
             list = choiceMapper.selectAll();
         }
    }
        return PageInfo.of(list);
    }


    public void updateById (Choice choice){
        choiceMapper.updateById(choice);
    }

    public void deleteById (Integer id){
        Choice choice= choiceMapper.seleById(id);
        choiceMapper.deleteById(id);
        //把对应的课程信息里面的已选人数-1
       Course course = courseMapper.selectById(choice.getCourseId());
       course.setAlreadyNum(course.getAlreadyNum() - 1);
       courseMapper.updateById(course);
    }

    public List<Choice> selectAll () {
        return choiceMapper.selectAll();
    }
    }
