package com.example.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.entity.Account;
import com.example.entity.Student;
import com.example.entity.Teacher;
import com.example.exception.CustomException;
import com.example.mapper.StudentMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 学生的信息业务层处理
 */
@Service
public class StudentService {
    @Resource
    private StudentMapper studentMapper;

    public void add(Student student){
        Student dbStudent = studentMapper.selectByUsername(student.getUsername());
        if(ObjectUtil.isNotEmpty(dbStudent)){
            throw new CustomException("用户名已存在");
        }
        if (ObjectUtil.isEmpty(student.getName())) {
            student.setName(student.getUsername());
        }
        student.setRole("STUDENT");
        student.setScore(0);

        if(ObjectUtil.isEmpty(student.getPassword())){
            student.setPassword("123456");
        }
        studentMapper.insert(student);
    }
    public PageInfo<Student> selectPage(Student student,Integer pageNum,Integer pageSize){
        List<Student>list;
        PageHelper.startPage(pageNum,pageSize);
        if(ObjectUtil.isNotEmpty(student.getName())){
            list=studentMapper.selectByName(student.getName());
        }else {
            list = studentMapper.selectAll();
        }
        return  PageInfo.of(list);
    }

    public void updateById(Student student) {
        studentMapper.updateById(student);
    }

    public void deleteById(Integer id) {
        studentMapper.deleteById(id);
    }

    public Student selectById(Integer id) {
        return studentMapper.selectById(id);
    }

    /**
     * 登录
     */
    public Student login(Account account) {
        Student dbStudent = studentMapper.selectByUsername(account.getUsername());
        if (ObjectUtil.isNull(dbStudent)) {
            throw new CustomException("用户不存在");
        }
        if (!account.getPassword().equals(dbStudent.getPassword())) {
            throw new CustomException("账号或密码错误");
        }
        // 返回包含学院名称的完整学生信息
        return studentMapper.selectById(dbStudent.getId());
    }

    /**
     *
     * 注册
     */
    public void register(Account account) {
        Student student = new Student();
        student.setUsername(account.getUsername());
        student.setPassword(account.getPassword());
        add(student);
    }

    /**
     * 修改密码
     */
    public void updatePassword(Account account) {
        Student dbStudent = studentMapper.selectByUsername(account.getUsername());
        if (ObjectUtil.isNull(dbStudent)) {
            throw new CustomException("用户不存在");
        }
        if (!account.getPassword().equals(dbStudent.getPassword())) {
            throw new CustomException("原密码错误");
        }
        dbStudent.setPassword(account.getNewPassword());
        studentMapper.updateById(dbStudent);
    }
}
