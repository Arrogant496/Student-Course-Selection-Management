<template>
        <div>
          <div class="card" style="margin-botton: 5px">
            <el-input v-model="data.name" style="width:300px;margin-right:10px" placeholder="请输入学生姓名"></el-input>
            <el-button type="primary" @click="load">查询</el-button>
            <el-button type="info" @click="reset">重置</el-button>
          </div>
          <div class="card">
              <div style="margin-botton:10px">
                  <el-button type="primary" @click="handleAdd">新 增</el-button>
              </div>
               <el-table :data="data.tableData" stripe>
                      <el-table-column label="用户名" prop="username"></el-table-column>
                      <el-table-column label="头像" prop="avatar">
                       <template v-slot="scope">
                       <el-image :src="scope.row.avatar" style="width: 40px; height: 40px; border-radius: 50%"></el-image>
                       </template>
                      </el-table-column>
                      <el-table-column label="姓名" prop="name"></el-table-column>
                      <el-table-column label="性别" prop="sex"></el-table-column>
                      <el-table-column label="学号" prop="code"></el-table-column>
                      <el-table-column label="学分" prop="score"></el-table-column>
                      <el-table-column label="角色" prop="role"></el-table-column>
                      <el-table-column label="操作" align="center" width="160">
                        <template #default="scope">
                          <el-button type="primary" @click="handleEdit(scope.row)">编辑</el-button>
                          <el-button type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
                        </template>
                      </el-table-column>
               </el-table>
          </div>

          <div class="card">
             <el-pagination background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"
             @current-change="changePage"/>

          </div>

          <el-dialog title="学生信息" width="40%" v-model="data.formVisible" :close-on-click-modal="false" destroy-on-close>
              <el-form :model="data.form" label-width="100px" style="padding-right: 50px">
            <el-form-item label="头像" prop="avatar">
            <el-upload :action="uploadUrl" list-type="picture" :on-success="handleImgSuccess">
            <el-button type="primary">上传图片</el-button>
          </el-upload>
        </el-form-item>
                <el-form-item label="账号" prop="username">
                     <el-input v-model="data.form.username" autocomplete="off" placeholder="请输入账号" />
                </el-form-item>

                <el-form-item label="姓名" prop="name">
                      <el-input v-model="data.form.name" autocomplete="off" placeholder="请输入姓名"/>
                </el-form-item>

                <el-form-item label="性别" prop="sex">
                      <el-select v-model="data.form.sex" placeholder="请选择性别" style="width:100%">
                          <el-option label="男" value="男" ></el-option>
                          <el-option label="女" value="女" ></el-option>
                      </el-select>
                </el-form-item>

                <el-form-item label="学号" prop="code">
                  <el-input v-model="data.form.code" autocomplete="off" placeholder="请输入学号"/>
                 </el-form-item>

                </el-form>
                <template #footer>
                <span class="dialog-footer">
                  <el-button @click="data.formVisible = false">取 消</el-button>
                  <el-button type="primary" @click="save">保 存</el-button>
                </span>
                </template>
           </el-dialog>
        </div>
      </template>

      <script setup>
      import {reactive} from "vue";
      import request from "@/utils/request";
      import {ElMessageBox, ElMessage} from "element-plus";
      //文件上传的接口
      const uploadUrl = import.meta.env.VITE_BASE_URL + '/files/upload'

      const data = reactive({
          formVisible:false,
          form:{},
          tableData:[],
          pageNum:1,
          pageSize:5,
          total:0,
          name:null
      })

          const load=()=>{
              request.get('/student/selectPage',{
                  params:{
                      pageNum:data.pageNum,
                      pageSize:data.pageSize,
                      name:data.name
                  }
              }).then(res=>{
                  if(res.code==='200'){
                      data.tableData=res?.data.list
                      data.total=res.data?.total
                  }else{
                      ElMessage.error(res.msg)
                  }
              })
          }

          const changePage=(pageNum)=>{
              data.pageNum=pageNum
              load()
          }
          const handleAdd=()=>{
              data.form={}
              data.formVisible=true
          }

          const handleEdit = (row) =>{
               data.form = JSON.parse(JSON.stringify(row))
               data.formVisible = true
               }

          const handleDelete = (id) => {
            ElMessageBox.confirm('删除后数据无法恢复，您确定删除吗?', '删除确认', { type: 'warning' }).then(res => {
          request.delete('/student/deleteById/'+id).then(res => {
          if(res.code ==='200'){
          ElMessage.success('操作成功')
           load()
          }else{
          ElMessage.error(res.msg)
          }
          })
          }).catch(err => {})
          }

          const add = () => {
            request.post('/student/add',data.form).then(res=>{
                if(res.code==='200'){
                ElMessage.success('操作成功')
                data.formVisible=false
                load()
                }else{
                ElMessage.error(res.msg)
                }
              })
              }
            const update = () => {
                request.put('/student/update',data.form).then( res => {
                  if(res.code==='200'){
                    ElMessage.success('操作成功')
                    data.formVisible=false
                    load()
                  } else{
                    ElMessage.error(res.msg)
                  }
              })
            }
          const save=()=>{
            data.form.id ? update() : add()
            }
          const reset=()=>{
          data.name=null
          load()
          }
          const handleImgSuccess = (res) => {
          data.form.avatar = res.data
          }
          load()
      </script>
      
      <style scoped>
      :deep(.el-dialog .el-form) {
        margin: 0 auto;
        max-width: 400px;
      }
      </style>
