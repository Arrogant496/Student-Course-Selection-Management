<template>
  <div>
    <div class="card" style="line-height: 30px; margin-bottom: 5px;">
      <div>欢迎您，{{ data.user.name }} 祝您今天过得开心！</div>
    </div>
    <div style="display: flex; gap: 10px;">
      <div class="card" style="flex: 50%; margin-top: 6px;">
        <div style="font-size:17px; font-weight:bold; padding:10px 10px 20px 10px">系统公告</div>
        <el-timeline>
          <el-timeline-item
              v-for="(item, index) in data.noticeData"
              :key="index"
              :timestamp="item.time"
          >
            {{item.title}} - {{ item.content }}
          </el-timeline-item>
        </el-timeline>
      </div>
      <!-- wzs:右侧：课程设计信息 -->
      <div class="card" style="flex: 50%; margin-top: 6px; position: relative; min-height: 200px;"> <!-- 相对定位容器 -->
        <div style="font-size:17px; font-weight:bold; padding:10px 10px 20px 10px">课程设计信息</div>
        <div style="padding: 0 10px; line-height: 1.8;">
          <div style="margin-bottom: 10px; font-size: 16px;">软件工程课程设计：学生选课管理系统</div> <!-- 主标题稍大 -->
          <div style="font-size: 14px; color: #666;">编写者：郭怡丹，郑嘉乐，吴志盛，卓凡涵，张逸航</div> <!-- 小一号字体 -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive } from "vue";
import request from "@/utils/request";
import {ElMessage} from "element-plus";

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  noticeData:[]
})

const loadNotice = () => {
  request.get('/notice/selectAll').then(res => {
    if (res.code === '200') {
      data.noticeData = res.data
    } else {
      ElMessage.error(res.msg)
    }
  })
}

loadNotice()
</script>